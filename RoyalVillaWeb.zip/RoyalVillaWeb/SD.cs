﻿namespace RoyalVillaWeb
{
    public static class SD
    {
        //Added Manual
        public enum ApiType
        {
            GET,
            POST,
            PUT,
            DELETE
        }
        public const string SessionToken = "JWTToken";
    }
}
